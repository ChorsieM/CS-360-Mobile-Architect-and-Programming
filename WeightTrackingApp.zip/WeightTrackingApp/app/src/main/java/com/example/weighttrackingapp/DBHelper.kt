package com.example.weighttrackingapp

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DBHelper(context: Context) : SQLiteOpenHelper(context, "WeightApp.db", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {
        // user table for login info
        db.execSQL("CREATE TABLE users(username TEXT PRIMARY KEY, password TEXT)")

        // weight entries table — stores daily weights for each user
        db.execSQL("""
            CREATE TABLE weights(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT,
                weight REAL,
                date TEXT,
                FOREIGN KEY(username) REFERENCES users(username)
            )
        """.trimIndent())
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // drop old user table (we can add a drop for weights if needed later)
        db.execSQL("DROP TABLE IF EXISTS users")
        db.execSQL("DROP TABLE IF EXISTS weights") // drop weights table on upgrade too
        onCreate(db)
    }

    // add a new user to the database
    fun insertUser(username: String, password: String): Boolean {
        val db = this.writableDatabase
        val values = ContentValues().apply {
            put("username", username)
            put("password", password)
        }
        val result = db.insert("users", null, values)
        return result != -1L
    }

    // check if the username + password match an existing user
    fun checkUser(username: String, password: String): Boolean {
        val db = this.readableDatabase
        val cursor = db.rawQuery(
            "SELECT * FROM users WHERE username = ? AND password = ?",
            arrayOf(username, password)
        )
        val exists = cursor.count > 0
        cursor.close()
        return exists
    }

    // add new weight entry to the table
    fun insertWeight(username: String, weight: Double, date: String): Boolean {
        val db = this.writableDatabase
        val values = ContentValues().apply {
            put("username", username)
            put("weight", weight)
            put("date", date)
        }
        val result = db.insert("weights", null, values)
        return result != -1L
    }

    // get all weight entries for the logged-in user
    fun getWeights(username: String): List<WeightEntry> {
        val weights = mutableListOf<WeightEntry>()
        val db = this.readableDatabase
        val cursor = db.rawQuery(
            "SELECT * FROM weights WHERE username = ?",
            arrayOf(username)
        )

        if (cursor.moveToFirst()) {
            do {
                val id = cursor.getInt(cursor.getColumnIndexOrThrow("id"))
                val weight = cursor.getDouble(cursor.getColumnIndexOrThrow("weight"))
                val date = cursor.getString(cursor.getColumnIndexOrThrow("date"))
                weights.add(WeightEntry(id, username, weight, date))
            } while (cursor.moveToNext())
        }

        cursor.close()
        return weights
    }

    // update an existing weight entry by ID
    fun updateWeight(id: Int, weight: Double, date: String): Boolean {
        val db = this.writableDatabase
        val values = ContentValues().apply {
            put("weight", weight)
            put("date", date)
        }
        val result = db.update("weights", values, "id = ?", arrayOf(id.toString()))
        return result > 0
    }

    // delete a weight entry by ID
    fun deleteWeight(id: Int): Boolean {
        val db = this.writableDatabase
        val result = db.delete("weights", "id = ?", arrayOf(id.toString()))
        return result > 0
    }
}
