package com.example.weighttrackingapp

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class WeightAdapter(private val weightList: List<WeightEntry>) :
    RecyclerView.Adapter<WeightAdapter.WeightViewHolder>() {

    // just holding the layout views for each row
    class WeightViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val txtDate: TextView = itemView.findViewById(R.id.txtDate)
        val txtWeight: TextView = itemView.findViewById(R.id.txtWeight)
    }

    // tells RecyclerView what layout to use for each row
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): WeightViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.weight_item, parent, false)
        return WeightViewHolder(view)
    }

    // puts actual data into each row
    override fun onBindViewHolder(holder: WeightViewHolder, position: Int) {
        val weightEntry = weightList[position]
        holder.txtDate.text = "Date: ${weightEntry.date}"
        holder.txtWeight.text = "Weight: ${weightEntry.weight} lbs"
    }

    // how many total rows to show
    override fun getItemCount(): Int {
        return weightList.size
    }
}