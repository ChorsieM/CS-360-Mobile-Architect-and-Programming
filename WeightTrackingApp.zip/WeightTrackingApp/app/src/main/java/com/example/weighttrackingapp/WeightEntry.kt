package com.example.weighttrackingapp

// this class just holds the weight info for one entry
data class WeightEntry(
    val id: Int,
    val username: String,
    val weight: Double,
    val date: String
)