package com.example.weighttrackingapp

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class DataGridActivity : AppCompatActivity() {

    private lateinit var dbHelper: DBHelper
    private lateinit var weightRecycler: RecyclerView
    private lateinit var welcomeText: TextView
    private lateinit var adapter: WeightAdapter

    // Using a hardcoded username for now; later this should come from login
    private val currentUsername = "testuser"

    fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_data_grid)

        // Initialize DB helper
        dbHelper = DBHelper(this)

        // Find views by ID
        weightRecycler = findViewById(R.id.weightRecycler)
        welcomeText = findViewById(R.id.welcomeText)

        // Show logged-in user name
        welcomeText.text = "Welcome, $currentUsername"

        // Get the weight entries from DB
        val weightList: List<WeightEntry> = dbHelper.getWeights(currentUsername)

        // Setup RecyclerView with a linear layout manager and adapter
        adapter = WeightAdapter(weightList)
        weightRecycler.layoutManager = LinearLayoutManager(this)
        weightRecycler.adapter = adapter
    }
}